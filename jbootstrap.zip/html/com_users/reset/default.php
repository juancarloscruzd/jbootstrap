<?php
/* ------------------------------------------------------------------------
  # Jootstrap - Twitter's Bootstrap for Joomla (with RocketTheme's Gantry administration)
  # ------------------------------------------------------------------------
  # author    Prieco S.A.
  # copyright Copyright (C) 2012 Prieco.com. All Rights Reserved.
  # @license - http://http://www.gnu.org/licenses/gpl-3.0.html GNU/GPL
  # Websites: http://www.prieco.com
  # Technical Support:  Forum - http://www.prieco.com/en/forum/index.html
  ------------------------------------------------------------------------- */

defined('_JEXEC') or die;

//JHtml::_('behavior.keepalive');
//JHtml::_('behavior.tooltip');
//JHtml::_('behavior.formvalidation');

require_once(JPATH_LIBRARIES . '/gantry/gantry.php');
$gantry->init();
gantry_import('core.utilities.gantryjformfieldaccessor');
?>
<div class="reset<?php echo $this->pageclass_sfx ?>">
    <?php if ($this->params->get('show_page_heading')) : ?>
        <h1>
            <?php echo $this->escape($this->params->get('page_heading')); ?>
        </h1>
    <?php endif; ?>

    <form id="user-registration" action="<?php echo JRoute::_('index.php?option=com_users&task=reset.request'); ?>" method="post" class="form-validate">

        <?php foreach ($this->form->getFieldsets() as $fieldset): ?>
            <p><?php echo JText::_($fieldset->label); ?></p>		<fieldset>
                <dl class="dl-horizontal">
                    <?php
                    foreach ($this->form->getFieldset($fieldset->name) as $name => $field):
                        $fa = new GantryJFormFieldAccessor($field);
                        if ($fa->getType() == "text")
                            $fa->addClass('inputbox');
                        ?>
                        <dt><?php echo $field->label; ?></dt>
                        <dd><?php echo $field->input; ?></dd>
                    <?php endforeach; ?>
                </dl>
            </fieldset>
        <?php endforeach; ?>

        <div>
            <div class="readon"><button type="submit" class="button btn"><?php echo JText::_('JSUBMIT'); ?></button></div>
            <?php echo JHtml::_('form.token'); ?>
        </div>
    </form>
</div>